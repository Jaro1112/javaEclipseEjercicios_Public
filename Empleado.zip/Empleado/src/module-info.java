/**
 * 
 */
/**
 * 
 */
module Empleado {
}