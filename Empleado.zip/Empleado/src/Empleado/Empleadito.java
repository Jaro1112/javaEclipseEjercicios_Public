package Empleado;

public class Empleadito {

	private int ID;
	private String nombre;
	private String apellido;
	private int salario;
	
	public Empleadito(int ID,String nombre, String apellido, int salario) {
		//Bob
		this.ID=ID;
		this.nombre=nombre;
		this.apellido=apellido;
		this.salario=salario;
		
	}
	
	public int getID() {
		return ID;
	}
	
	public String getNombre() {
		return nombre;
	}
	
	public String getApellido() {
		return apellido;
	}
	
	public int getSalario() {
		return salario;
	}
	
	public void setSalario(int salario) {
		this.salario=salario;
	}
	
	public int getAnyoSalario() {
		int anyoSalario=12*this.salario;
		return anyoSalario;
	}
	
	public int result() {
		
		int porcent = 50;
		
		
		int subSalario = (porcent*salario)/100;
		int resultado=salario+subSalario;
		return resultado;
	}
		

	public String toString() {
		return "Empleadito: ID:"+ID+
				", Nombre:"+nombre+
				", Apellido:"+apellido+
				", Salario:"+salario;
	}

}
