package Empleado;

public class Probando {

	public Probando(){
	
	}
	
	public static void main(String[] args) {
		Empleadito lentoRodriguez = new Empleadito(1,"Lento","Rodriguez",5);		
		System.out.println(lentoRodriguez);
		System.out.println("salario del lento con +50% de ganancias: "+lentoRodriguez.result());
		System.out.println("Salario al anyo del lento :" + lentoRodriguez.getAnyoSalario());
		
	}

	
}
