package Invoice;

public class Probando {
	
	
		public static void main(String[] args) {
			Invoicee Invoiceee = new Invoicee("1111111","7%",15,50);
			
			System.out.println("Nombre del producto: Camisa");
			System.out.println(Invoiceee);
		}
}


