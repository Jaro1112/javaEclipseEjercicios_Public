package ejercicioCirculo;

public class PruebaFiguras {

	public static void main(String args[]) {
		Circulo figura1 = new Circulo(2);

		System.out.println("El área del círculo es = " + figura1.calcularArea());
		System.out.println("El perímetro del círculo es = " + figura1.calcularPerímetro());
		System.out.println();


	}
}


